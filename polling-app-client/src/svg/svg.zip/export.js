//const svg = require('./store.json');

const fs = require('fs')

fs.readFile('./store.json', 'utf8', (err, jsonString) => {
    if (err) {
        console.log("Error reading file from disk:", err)
        return
    }
    try {
        const store = JSON.parse(jsonString);

        parsingPages(store);
} catch(err) {
        console.log('Error parsing JSON string:', err)
    }
})

function header(title, desc, width, height, viewBox) {
    console.log(`
<?xml version="1.0" standalone="no"?>
<?xml-stylesheet type="text/css" href="style8.css"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg width="${width}" height="${height}" viewBox="${viewBox}"
    xmlns="http://www.w3.org/2000/svg" version="1.1"
    xmlns:xlink="http://www.w3.org/1999/xlink">

<title>${title}/title>
<desc>${desc}</desc>`);
}

function parsingPages(store) {

    const {pageSize, pages} = store;


    header('Sample', 'generated from pagebuilder', pageSize.backgroundLayerWidth, pageSize.backgroundLayerHeight, '0 0 900 900');
    for (pageNumber in pages) {
        if (store.pages.hasOwnProperty(pageNumber)) {
            parsingEachPage(pageNumber, pages[pageNumber]);
        }
    }

}

function parsingEachPage(pageNumber, page) {

    const { layers } = page;

    for (layerNumber in layers) {
        if (layers.hasOwnProperty(layerNumber)) {
            parsingEachLayer(layerNumber, layers[layerNumber]);
        }
    }
}

function parsingEachLayer(layerNumber, layer) {
    
    const { render } = layer;

    for (key in layer.render) {
        parsingRender(layer.render[key]);
    }
}

function parsingRender(drawing) {
    console.log(drawing);

}